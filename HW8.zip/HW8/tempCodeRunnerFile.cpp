cout << "Enter assignment file: ";
    // cin >> assignmentFile;